--------------------
ModLDAP
--------------------
Version: 2.4.1 alpha
Since: December 31th, 2015
Author: Zaenal Muttaqin <zaenal(#)lokamaya.com>
Branched from: ActiveDirectoryRedux 2.4.0 beta1
--------------------

This is an LDAP integration for MODX Revolution, branched from ActiveDirectoryRedux.

## Installation

1. Simply install via Package Management in MODX Revolution Manager page.
2. After installing this package, go to System Setting > ModLDAP, change some setting there.

By default, ModLDAP has been disabled. So you have to edit some System Setting first...


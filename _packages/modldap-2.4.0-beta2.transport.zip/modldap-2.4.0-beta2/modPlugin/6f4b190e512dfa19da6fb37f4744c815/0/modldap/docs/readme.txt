--------------------
ModLDAP
--------------------
Version: 2.4.0 beta2
Since: January 1st, 2016
Author: Zaenal Muttaqin <zaenal@lokamaya.com>
Branched from: ActiveDirectoryRedux 2.4.0 beta1 by Shaun McCormick <shaun@modx.com>
--------------------

This is an LDAP integration for MODX Revolution, branched from ActiveDirectoryRedux.

## Installation

1. If you plan to add LDAP user to MODx, first create "LDAP" usergroups on MODx.
2. Simply install via Package Management in MODX Revolution Manager page.

From there, you'll need to setup some settings. Go to System Setting, and choose "modldap".


<?php

$xpdo_meta_map = array (
  'modUser' => 
  array (
    0 => 'modLDAPUser',
  ),
);
<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
ModLDAP
--------------------
Version: 2.4.1 alpha
Since: December 31th, 2015
Author: Zaenal Muttaqin <zaenal(#)lokamaya.com>
Branched from: ActiveDirectoryRedux 2.4.0 beta1
--------------------

This is an LDAP integration for MODX Revolution, branched from ActiveDirectoryRedux.

## Installation

1. Simply install via Package Management in MODX Revolution Manager page.
2. After installing this package, go to System Setting > ModLDAP, change some setting there.

By default, ModLDAP has been disabled. So you have to edit some System Setting first...

',
    'changelog' => 'Changelog for ModLDAP.

ModLDAP 2.4.1-alpha
======================
- Developed and tested on MODX Revo 2.4.2
- Refactoring modLDAP base class
- Refactoring LDAP Driver for connection and authentication
- Refactoring modLDAPUser (extends modUSER)
- Plugin has been modified
- A lot of modification to ModLDAP System Setting
- [NEW] Snippet for debuging: ModLDAPDebug
- [NEW] Import user photo from LDAP 
- [NEW] Add LDAP User to certain group and role
- [NOT IMPLEMENTED] Add LDAP Group to MODX


ModLDAP 2.4.0-beta1
======================
- Branched from ActiveDirectoryRedux 2.4.0-beta1
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd4f3c08fdffc484ca1ae91cd36b60691',
      'native_key' => 'modldap',
      'filename' => 'modNamespace/64084eb518046231c352f2214bd17c30.vehicle',
      'namespace' => 'modldap',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'b9f5d7c20e4439d01709194aa0f79419',
      'native_key' => NULL,
      'filename' => 'modPlugin/b49f8d61dbd152b732694931096e9c1a.vehicle',
      'namespace' => 'modldap',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => 'b299057d4dbc809fd8f2b0baa9fdcb4f',
      'native_key' => NULL,
      'filename' => 'modSnippet/0524c858b6955569d6e858870321e2bb.vehicle',
      'namespace' => 'modldap',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '216d8f8ad995a47c68150a78278e898f',
      'native_key' => 'modldap.enabled',
      'filename' => 'modSystemSetting/5e49ad9f74beaec6a5c5226dd575e11f.vehicle',
      'namespace' => 'modldap',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebac29893fbc93e192a0b783949f322b',
      'native_key' => 'modldap.login_manager_disable',
      'filename' => 'modSystemSetting/c3988bf175e8b9db4c77d130501730c6.vehicle',
      'namespace' => 'modldap',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6520d6adbe91ebb3ef90648a4173330',
      'native_key' => 'modldap.login_web_disable',
      'filename' => 'modSystemSetting/4e1b962a9ebeb6ae7d25c99e52a6ea88.vehicle',
      'namespace' => 'modldap',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f36df82a65af3425cc85d280834ec8f',
      'native_key' => 'modldap.domain_controllers',
      'filename' => 'modSystemSetting/c1477c59bf88b54d11347fdfbfcd4862.vehicle',
      'namespace' => 'modldap',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f90dde4c90b09b0e7e17d09c8bf62aa',
      'native_key' => 'modldap.connection_type',
      'filename' => 'modSystemSetting/4639c7eaadf61737fcf5d748b2220ee6.vehicle',
      'namespace' => 'modldap',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96bbda5696f49ad813c2468e34e17c94',
      'native_key' => 'modldap.ssl_port',
      'filename' => 'modSystemSetting/9564c1a63b8d5728ed5c87c47262e9f8.vehicle',
      'namespace' => 'modldap',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ca9147e39b075151aa48e8bfd54569f',
      'native_key' => 'modldap.ldap_opt_protocol_version',
      'filename' => 'modSystemSetting/31ebf8e562175e152db2636b99712604.vehicle',
      'namespace' => 'modldap',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72eb5dbd828e804142216ddaa41269c9',
      'native_key' => 'modldap.ldap_opt_referrals',
      'filename' => 'modSystemSetting/63878496e008c9271176b805a02b6896.vehicle',
      'namespace' => 'modldap',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a276b01a498ac3593666aa8305e2481',
      'native_key' => 'modldap.ldap_opt_network_timeout',
      'filename' => 'modSystemSetting/1b497a815600a5e9d8af3a75f094168a.vehicle',
      'namespace' => 'modldap',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd16d21811ef7a0b5aca81b29b6705f27',
      'native_key' => 'modldap.ldap_opt_timelimit',
      'filename' => 'modSystemSetting/6fa0338e9b8c8d0e1e02f2c5b7a471ad.vehicle',
      'namespace' => 'modldap',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbf88c5c01622c109ba27bfab1c3ea5d',
      'native_key' => 'modldap.ldap_opt_debug',
      'filename' => 'modSystemSetting/b1aebabbcac6fe889b232096df0146a2.vehicle',
      'namespace' => 'modldap',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b45807173147e7524765b7ef4bd7175',
      'native_key' => 'modldap.format_ldap_bind',
      'filename' => 'modSystemSetting/ed23df418314727a11ab0314ce5c31b7.vehicle',
      'namespace' => 'modldap',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f3c3e1945be273286d5dafa3d169094',
      'native_key' => 'modldap.format_ldap_search_basedn',
      'filename' => 'modSystemSetting/578be1857eb0734f5b4681ef3487d418.vehicle',
      'namespace' => 'modldap',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cd2ca925c88da45bd617f0f0106de69',
      'native_key' => 'modldap.format_ldap_search_filter',
      'filename' => 'modSystemSetting/a455f1d2c69531472bcfe79297a93417.vehicle',
      'namespace' => 'modldap',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbe5c0204bd86836ced194dc679e46e4',
      'native_key' => 'modldap.format_ldap_groups',
      'filename' => 'modSystemSetting/f7bd63c85df9838e849c8d480eecf3a0.vehicle',
      'namespace' => 'modldap',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ab8ce1f5ea99d756d697831dd87c2e3',
      'native_key' => 'modldap.autoadd_usergroups',
      'filename' => 'modSystemSetting/3b1135c25111437de43040955c86f49f.vehicle',
      'namespace' => 'modldap',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ed0479a278906b9cbb83c2235833a45',
      'native_key' => 'modldap.autoadd_usergroups_name',
      'filename' => 'modSystemSetting/a0fe08f33d39efaaec98f0bc2f11fe53.vehicle',
      'namespace' => 'modldap',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '484aaf0a8489d73723d7d06ddb631560',
      'native_key' => 'modldap.autoadd_usergroups_role',
      'filename' => 'modSystemSetting/8fd9431030ec2ebce11e8648cf4d473e.vehicle',
      'namespace' => 'modldap',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd17fce776d1d29263a02fb827c7e2ee2',
      'native_key' => 'modldap.ldap_group_add',
      'filename' => 'modSystemSetting/c61d14eba4030e3193325448c7d4220c.vehicle',
      'namespace' => 'modldap',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29d2bf787e01813d6eef58c280c41975',
      'native_key' => 'modldap.field_fullname',
      'filename' => 'modSystemSetting/0c35ebd1d8394fcc39fca0b2c0209a6a.vehicle',
      'namespace' => 'modldap',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba2f84d743ee0283b0e86e89180b3266',
      'native_key' => 'modldap.field_email',
      'filename' => 'modSystemSetting/1f51db8998009ab82e618b92664cbf30.vehicle',
      'namespace' => 'modldap',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aac7f78f9abd01fc6fa8e185f0c43b0a',
      'native_key' => 'modldap.field_phone',
      'filename' => 'modSystemSetting/4c3e5e83950f2f0f1b76180907965e47.vehicle',
      'namespace' => 'modldap',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58db62e820cdd574ff17c08209ea6eca',
      'native_key' => 'modldap.field_mobilephone',
      'filename' => 'modSystemSetting/bc288278ff1edf6bdc40d4c72676ccc6.vehicle',
      'namespace' => 'modldap',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16310edf57210c598f613a924dfc3760',
      'native_key' => 'modldap.field_dob',
      'filename' => 'modSystemSetting/8d8743460ace6bee5ff441f0b9770c66.vehicle',
      'namespace' => 'modldap',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29a68be5e45dc1a6989013d2781fb4e5',
      'native_key' => 'modldap.field_gender',
      'filename' => 'modSystemSetting/3ed4aa0e4875f42d6a9214f73bc21592.vehicle',
      'namespace' => 'modldap',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd48f59da9ebe18711353548cf109338f',
      'native_key' => 'modldap.field_address',
      'filename' => 'modSystemSetting/d9560c44ba0d8138c2622253fb2b55ee.vehicle',
      'namespace' => 'modldap',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6ada8af5a711c4fad8ca69e69711115',
      'native_key' => 'modldap.field_country',
      'filename' => 'modSystemSetting/a2ffab444f48746557343c0cc4eea7a1.vehicle',
      'namespace' => 'modldap',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18cbd3bbfde0dca32606b113a9046b59',
      'native_key' => 'modldap.field_city',
      'filename' => 'modSystemSetting/f08d893b53da301a58f982b0a6c087c7.vehicle',
      'namespace' => 'modldap',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6264eda659c40cffe2694f368759c6ae',
      'native_key' => 'modldap.field_state',
      'filename' => 'modSystemSetting/4f0726e1c379ebff340ea4436f790cf7.vehicle',
      'namespace' => 'modldap',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '750ed05a33e8925e626d6c3e92b0f83d',
      'native_key' => 'modldap.field_zip',
      'filename' => 'modSystemSetting/cfb23c302630a845e1eab9d5c1a504fa.vehicle',
      'namespace' => 'modldap',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21b4e51ffbf8e9d40a34f5ace6d2f39e',
      'native_key' => 'modldap.field_fax',
      'filename' => 'modSystemSetting/6499cdcb8e1ad440479657052ffe4a60.vehicle',
      'namespace' => 'modldap',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fd8f76f748123474c957f2f48db98a3',
      'native_key' => 'modldap.field_photo',
      'filename' => 'modSystemSetting/dc6c6cedfa69486659ddfdd7a9a70cdc.vehicle',
      'namespace' => 'modldap',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81ca02e3839c3b765fea82950acccd7c',
      'native_key' => 'modldap.field_comment',
      'filename' => 'modSystemSetting/f05560e599be28a9f9653a87876273c8.vehicle',
      'namespace' => 'modldap',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30fd57980154b9cadad6296a0364af16',
      'native_key' => 'modldap.field_website',
      'filename' => 'modSystemSetting/8b62dbe5b9c1fb5973130a889cdcb24f.vehicle',
      'namespace' => 'modldap',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e21c9302b4e4b6837752b329870eac1',
      'native_key' => 'modldap.field_memberof',
      'filename' => 'modSystemSetting/734c9b841201aaf435a341356f34a708.vehicle',
      'namespace' => 'modldap',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64ccc65790a81355af69eb40c3f54c35',
      'native_key' => 'modldap.photo_path',
      'filename' => 'modSystemSetting/430b3c274ce36da8170a9a8c27394861.vehicle',
      'namespace' => 'modldap',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '700c1130e988512bf459777d20ca61f3',
      'native_key' => 'modldap.photo_url',
      'filename' => 'modSystemSetting/52adb782c09a1d8bd0a791fa3db6bee0.vehicle',
      'namespace' => 'modldap',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c61c8165b3804b57fa03fa470ff6b33',
      'native_key' => 'modldap.photo_import_size',
      'filename' => 'modSystemSetting/b9d4455e81715f946f8d14e83a9b2bdb.vehicle',
      'namespace' => 'modldap',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31e37d3e28bf72536541a6e40d080e70',
      'native_key' => 'modldap.photo_import_quality',
      'filename' => 'modSystemSetting/0db58fbc51906b10080322fd4d20dc54.vehicle',
      'namespace' => 'modldap',
    ),
  ),
);
var ModLDAP = function(config) {
    config = config || {};
    ModLDAP.superclass.constructor.call(this, config);
};

Ext.extend(ModLDAP,Ext.Component,{
    page:{}, window:{}, grid:{}, tree:{}, panel:{}, combo:{}, config: {}, view: {}
});

Ext.reg('modldap', ModLDAP);

var ModLDAP = new ModLDAP();
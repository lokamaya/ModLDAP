<?php
require_once (dirname(dirname(__FILE__)) . '/modldap.class.php');
class modLDAP_mysql {}
<?php
$xpdo_meta_map['modLDAP']= array (
  'package' => 'modldap',
);

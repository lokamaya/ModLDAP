<?php
$xpdo_meta_map['modLDAPUser']= array (
  'package' => 'modldap',
  'version' => NULL,
  'table' => 'users',
  'extends' => 'modUser',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);

<?php
require_once (dirname(dirname(__FILE__)) . '/modldapuser.class.php');
class modLDAPUser_mysql extends modLDAPUser {}
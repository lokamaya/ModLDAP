--------------------
Active Directory X
--------------------
Version: 2.1.1
Since: June 27th, 2013
Author: Shaun McCormick <shaun@modx.com>
--------------------

Integrates Active Directory into MODX authentication.


